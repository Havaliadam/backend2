export const initialTaskState = {
  id: '',
  title: '',
  description: '',
  category: 'Genel',
  completed: false,
  createdAt: ''
};
