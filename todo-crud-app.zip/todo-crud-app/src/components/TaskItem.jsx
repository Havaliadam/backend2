export default function TaskItem({ task, onDelete, onEdit, onToggleStatus }) {
  return (
    <div className={`p-4 rounded-xl border transition-all ${
      task.completed ? 'bg-slate-50 border-slate-200 opacity-75' : 'bg-white border-slate-200 shadow-sm'
    }`}>
      <div className="flex items-start justify-between gap-4">
        <div className="flex items-start gap-3 flex-1">
          <input
            type="checkbox"
            checked={task.completed}
            onChange={() => onToggleStatus(task.id)}
            className="mt-1 h-5 w-5 rounded border-slate-300 text-indigo-600 focus:ring-indigo-500 cursor-pointer"
          />
          <div>
            <div className="flex items-center gap-2">
              <span className={`font-semibold ${task.completed ? 'line-through text-slate-400' : 'text-slate-800'}`}>
                {task.title}
              </span>
              <span className="text-xs px-2 py-0.5 rounded-full bg-indigo-50 text-indigo-600 font-medium">
                {task.category}
              </span>
            </div>
            {task.description && (
              <p className={`text-sm mt-1 ${task.completed ? 'line-through text-slate-400' : 'text-slate-600'}`}>
                {task.description}
              </p>
            )}
            <span className="text-xs text-slate-400 mt-2 block">Tarih: {task.createdAt}</span>
          </div>
        </div>

        <div className="flex items-center gap-1">
          <button
            onClick={() => onEdit(task)}
            className="p-1.5 text-slate-500 hover:text-indigo-600 hover:bg-slate-100 rounded-md transition-colors"
            title="Düzenle"
          >
            ✎ Düzenle
          </button>
          <button
            onClick={() => onDelete(task.id)}
            className="p-1.5 text-slate-500 hover:text-red-600 hover:bg-slate-100 rounded-md transition-colors"
            title="Sil"
          >
            ✕ Sil
          </button>
        </div>
      </div>
    </div>
  );
}
