import TaskItem from './TaskItem';

export default function TaskList({ tasks, onDelete, onEdit, onToggleStatus }) {
  if (tasks.length === 0) {
    return (
      <div className="text-center py-12 bg-white rounded-xl border border-slate-200">
        <p className="text-slate-500 font-medium">Henüz kayıtlı bir görev bulunmuyor.</p>
        <p className="text-xs text-slate-400 mt-1">Yukarıdaki formdan yeni bir görev ekleyebilirsiniz.</p>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {tasks.map((task) => (
        <TaskItem
          key={task.id}
          task={task}
          onDelete={onDelete}
          onEdit={onEdit}
          onToggleStatus={onToggleStatus}
        />
      ))}
    </div>
  );
}
