import { useState, useEffect } from 'react';
import TaskForm from '../components/TaskForm';
import TaskList from '../components/TaskList';

export default function Dashboard() {
  // 1. READ (LocalStorage'dan oku veya boş dizi ata)
  const [tasks, setTasks] = useState(() => {
    const localData = localStorage.getItem('crud_tasks_v1');
    return localData ? JSON.parse(localData) : [
      {
        id: '1',
        title: 'React ve Tailwind kurulumu yapıldı',
        description: 'Proje dosya ağaç yapısı components, pages ve interfaces olarak ayrıldı.',
        category: 'Eğitim',
        completed: true,
        createdAt: new Date().toLocaleDateString('tr-TR')
      },
      {
        id: '2',
        title: 'Netlify üzerinde canlıya alma',
        description: 'GitHub deposu Netlify servisine bağlanıp dağıtılacak.',
        category: 'İş',
        completed: false,
        createdAt: new Date().toLocaleDateString('tr-TR')
      }
    ];
  });

  const [editingTask, setEditingTask] = useState(null);

  // Veri her değiştiğinde LocalStorage senkronizasyonu
  useEffect(() => {
    localStorage.setItem('crud_tasks_v1', JSON.stringify(tasks));
  }, [tasks]);

  // 2. CREATE & UPDATE
  const handleSaveTask = (taskData) => {
    if (editingTask) {
      setTasks(tasks.map((t) => (t.id === taskData.id ? taskData : t)));
      setEditingTask(null);
    } else {
      setTasks([taskData, ...tasks]);
    }
  };

  // 3. DELETE
  const handleDeleteTask = (id) => {
    setTasks(tasks.filter((t) => t.id !== id));
    if (editingTask && editingTask.id === id) {
      setEditingTask(null);
    }
  };

  // Tamamlandı durumunu güncelle
  const handleToggleStatus = (id) => {
    setTasks(
      tasks.map((t) =>
        t.id === id ? { ...t, completed: !t.completed } : t
      )
    );
  };

  return (
    <main className="max-w-2xl mx-auto px-4 py-10">
      <header className="text-center mb-8">
        <h1 className="text-3xl font-extrabold text-slate-900 tracking-tight">
          Modern Görev & Proje Takibi
        </h1>
        <p className="text-slate-500 mt-2 text-sm">
          React, Tailwind CSS ve LocalStorage tabanlı CRUD uygulaması
        </p>
      </header>

      <TaskForm
        onSaveTask={handleSaveTask}
        editingTask={editingTask}
        onCancelEdit={() => setEditingTask(null)}
      />

      <section>
        <div className="flex justify-between items-center mb-4">
          <h2 className="font-semibold text-slate-700">Görev Listesi</h2>
          <span className="text-xs bg-slate-200 text-slate-700 px-2 py-1 rounded-md font-medium">
            Toplam: {tasks.length}
          </span>
        </div>
        <TaskList
          tasks={tasks}
          onDelete={handleDeleteTask}
          onEdit={(task) => setEditingTask(task)}
          onToggleStatus={handleToggleStatus}
        />
      </section>
    </main>
  );
}
